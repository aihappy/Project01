create PROCEDURE     PROC_LOG(P_PROC_TYPE IN VARCHAR2,
                                     P_PROC_NAME IN VARCHAR2,
                                     P_PROC_LOG  IN VARCHAR2,
                                     P_LOG_FLAG  IN INTEGER)
/*
  加工内容:存过执行日志
  来源表：所有存过的执行日志
  目的表：PROC_LOG_INFO
  创建时间:2017-02-24
  */
 AS
BEGIN
  INSERT INTO PROC_LOG_INFO
    (PROC_TYPE, PROC_NAME, PROC_LOG, LOG_FLAG, PROC_TIME)
  VALUES
    (P_PROC_TYPE, P_PROC_NAME, P_PROC_LOG, P_LOG_FLAG, SYSTIMESTAMP);
END;
/

