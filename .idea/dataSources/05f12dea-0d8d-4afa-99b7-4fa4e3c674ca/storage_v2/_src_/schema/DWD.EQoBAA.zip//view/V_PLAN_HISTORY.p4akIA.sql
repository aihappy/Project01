create view V_PLAN_HISTORY as
  select t.id, t.parent_id, t.show_name, t.detail_id, t.office_id, 0 as selected
from (
    select 'f'||t.id as id, '0' as parent_id, t.name as show_name, t.id as detail_id, t.office_id
        from t_task_form t where t.del_flag='0'
    union all
        select 'p'||t.id as id, 'f'||f.id as parent_id, t.name as show_name, t.id as detail_id, f.office_id
        from t_parent_children t left join t_task_form f on t.task_form_id=f.id and f.del_flag='0'
        where t.del_flag='0'
) t
order by t.id
/

