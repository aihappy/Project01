create view V_DATA as
  select a.id,
       a.parentid,
       a.basicid,
       c.assetnum as sbid,
       c.simplename sbname,
       b.id as itemid,
       b.name        itemname,
       a.value,
       a.remark,
       b.data_type
  from t_data a, t_data_item b, t_sb c ,t_form_header d,t_form_detail e
 where a.sbid = e.id
   and e.asset_id = c.assetnum(+)
   and a.itemid = d.id
   and d.itemid = b.id(+)
/

