create view V_AI_YIFA_MAX as
  select cid, count(*) as num
  from (select nextid - id-1 as cid
          from (select t.id,
                       lead(t.id, 1, null) over(order by t.id) as nextId
                  from ai_yifa_888 t
                 where t.dx = '大'
                 order by t.id asc))
 group by cid
 order by cid
/

