create view V_DATA_DWD as
  select a.id,
       a.parentid as parent_id,
       a.basicid as basic_id,
       d.asset_id as sb_id,
       e.itemid as item_id,
       a.value,
       c.starttime as start_time
  from t_data a,t_data_basic c,t_form_detail d,t_form_header e
  where  a.sbid=d.id
  and a.itemid=e.id
  and a.basicid=c.id
  and a.value is not null
  and a.value <> '——'
/

