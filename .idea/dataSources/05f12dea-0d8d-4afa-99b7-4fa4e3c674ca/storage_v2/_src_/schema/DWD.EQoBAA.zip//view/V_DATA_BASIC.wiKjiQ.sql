create view V_DATA_BASIC as
  select a.ID,
a.ZYBZID,
g.name as zybzname,
a.starttime,
a.endtime,
p.jobform_id as taskid,
p.name as taskname,
p.task_type_id as tasktypeid,
'' as tasktypename,
a.FZRID as fzrname,
a.ZYRID as zyrname,
a.TQ,
a.CHECKDATE,
a.SHRID as shrname,
p.office_id,
p.form_no,
p.technical_no,
a.temperature,
a.humidity,
p.form_class_id as formclassid,
p.finished,
p.plan_task_id
  from t_data_basic a
  left join sys_office g on  a.zybzid=g.id and g.del_flag='0'
  left join (select p.id as plan_task_id,p.task_id,t.form_no,t.form_class_id,t.technical_no,p.office_id,p.jobform_id,p.name,p.task_type_id,p.finished
  from t_plan_task p left join t_task_form t on t.id=p.jobform_id and t.del_flag='0' where p.del_flag='0'
  ) p on p.task_id=a.id
  where a.del_flag='0'
/

