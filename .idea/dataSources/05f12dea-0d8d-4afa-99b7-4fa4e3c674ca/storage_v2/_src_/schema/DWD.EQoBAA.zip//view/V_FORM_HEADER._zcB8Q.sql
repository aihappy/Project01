create view V_FORM_HEADER as
  select t.id, t.parent_id, t.show_name, t.header_id, t.detail_id, t.detail_name
from (
    select 'h'||t.id||'_'||rownum as id, 'd'||p.id as parent_id, t.itemname as show_name,
           t.id as header_id, p.id as detail_id, p.asset_name as detail_name
    from t_form_header t, t_form_detail p where t.formid=p.formid and t.data_type =1) t
order by t.id
/

