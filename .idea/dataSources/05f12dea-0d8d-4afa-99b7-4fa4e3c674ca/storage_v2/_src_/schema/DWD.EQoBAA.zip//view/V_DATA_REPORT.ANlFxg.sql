create view V_DATA_REPORT as
  select
            t1.id,
            t1.value,
            t1.sbid,
            t1.itemid,
            t2.endtime,
            t1.UPPER_VALUE,
            t1.LOWER_VALUE
       from v_data_ul t1 left join v_data_basic t2
       on t2.id=t1.basicid
       where t2.endtime is not null
       order by t2.endtime asc
/

