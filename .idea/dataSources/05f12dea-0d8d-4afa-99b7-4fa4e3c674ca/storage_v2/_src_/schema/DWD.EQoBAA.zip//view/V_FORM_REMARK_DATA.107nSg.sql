create view V_FORM_REMARK_DATA as
  select t.id,t.basicid,b.formid,t.itemid,b.sm,t.value from t_form_remark_data t,t_form_remark b
where t.itemid(+)=b.id and t.formid(+)=b.formid
/

