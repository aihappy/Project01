create view V_FORM_EVALUATE_DATA as
  select t.taskid,
       t.del_flag,
       t.pj,
       t.task_form_id,
       t.id,
       t.is_confirm,
       t.sort,
       p.id as data_id,
       p.basicid,
       p.itemid,
       p.isstate,
       p.value
  from (select t.taskid, t.del_flag, b.pj, b.task_form_id, b.id,b.is_confirm,b.sort
          from t_task_form t, T_form_evaluate b
         where t.id = b.task_form_id) t
  left join t_form_evaluate_data p
    on p.itemid = t.id
   and p.basicid = t.taskid
/

