create view V_DATA_ANALIS as
  select t.ID,
       SBID,
       SBNAME,
       ITEMID,
       ITEMNAME,
       (case
         when VALUE = '正常' then
          '0'
         when value = '不正常' then
          '1'
         else
          value
       end) value,
       to_char(STARTTIME, 'yyyymmdd') starttime,
       t.data_type
  from v_data t, v_data_basic b
 where t.basicid = b.ID
   and t.value is not null
   and t.value <> '——'
   and t.data_type=1
/

