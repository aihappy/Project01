create view V_DATA_ANALYZE as
  select a.id,
       a.parentid as parent_id,
       a.basicid as basic_id,
       a.sbid as sb_id,
       a.itemid as item_id,
       d.itemname as item_name,
       d.sx as item_sort,
       to_number(a.value) as value,
       c.starttime as start_time
  from t_data a,t_data_basic c,t_form_header d
  where a.basicid=c.id
  and a.itemid=d.id
  and is_number(a.value) ='Y'
  and a.value is not null
 -- and a.value <> '——'
  --and a.value <> '--'
  --and a.value <> '正常'
/

