create view V_DATA_UL as
  select a."ID",a."PARENTID",a."BASICID",a."SBID",a."SBNAME",a."ITEMID",a."ITEMNAME",a."VALUE",a."REMARK",a."DATA_TYPE", b.uvalue UPPER_VALUE, b.lvalue LOWER_VALUE
  from v_data a
  left join t_form_validate b
    on a.parentid = b.formid
   and a.itemid = b.item_id
   and a.sbid = b.asset_id
   and b.del_flag = '0'
/

