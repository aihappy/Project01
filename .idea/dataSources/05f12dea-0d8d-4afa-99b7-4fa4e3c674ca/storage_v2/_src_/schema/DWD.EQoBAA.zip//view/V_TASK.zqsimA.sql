create view V_TASK as
  select a.ID,
a.NAME,
DESCRIPT,
QUALITY,
JLCD,
a.REMARK,
PERIODID,
b.name periodname,
TASKTYPEID,
FORMCLASSID,
c.name tasktypename from T_TASK  a ,t_period_type b,t_task_type c
where a.periodid=b.id(+) and a.tasktypeid=c.id(+)
/

