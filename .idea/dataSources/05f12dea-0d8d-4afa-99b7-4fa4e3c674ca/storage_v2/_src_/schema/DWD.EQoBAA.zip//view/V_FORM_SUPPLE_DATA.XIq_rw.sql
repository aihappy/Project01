create view V_FORM_SUPPLE_DATA as
  select t.id,t.basicid,b.formid,t.itemid,b.fj,b.fjsm,t.value from t_form_supple_data t,t_form_supple b
where t.itemid=b.id
/

