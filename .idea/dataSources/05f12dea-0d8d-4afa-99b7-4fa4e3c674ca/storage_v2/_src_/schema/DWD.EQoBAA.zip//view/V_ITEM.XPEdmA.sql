create view V_ITEM as
  select t.id,t.parent_id,t.show_name,t.sb_id,t.item_id,t.sb_name,t.item_name,p.id as analyze_id,
      (case
         when p.del_flag=0 then
          1
         else
          0
       end) as selected
from (select 't'||b.asset_id ||c.id  as id,
       's'||b.asset_id as PARENT_ID,
       c.name as show_name,
       b.asset_id as sb_id,
       c.id as item_id,
       (case
                 when d.simplename is null then
                  d.description
                 else
                  d.simplename
               end) as sb_name,
       c.name as item_name
  from T_FORM_HEADER a, t_form_detail b, t_data_item c,t_sb d
 where a.itemid = c.id
   and a.formid = b.formid
   and d.assetnum = b.asset_id
   and d.del_flag = 0
   and b.del_flag = 0
   and a.del_flag = 0
   and c.del_flag = 0
   group by b.asset_id,c.id,c.name,d.simplename,d.description ) t
   left join
   analyze_sb_item p on p.sb_id=t.sb_id and p.item_id=t.item_id
/

