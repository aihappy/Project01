create view V_FORM_PROCESS_RISK_DATA as
  select t.taskid,
       t.del_flag,
       t."ID",
       t."TASK_FORM_ID",
       t."GC",
       t."GCMS",
       t.sort,
       t.is_confirm,
       p."DETAIL_DATA_ID",
       p."DATA_ID",
       p."ISSTATE",
       p."VALUE",
       p."BASICID",
       p."ITEMID"
  from (select t.taskid,
               t.del_flag,
               b."ID",
               b."TASK_FORM_ID",
               b."GC",
               b.is_confirm,
               b.sort,
               b."GCMS"
          from t_task_form t,
               (select a.id,
                       b.task_form_id,
                       a.is_confirm,
                       a.sort,
                       a.RISK             as gc,
                       a.CONTROL_MEASURES as gcms
                  from t_Form_Process_risk a, t_form_process b
                 where a.form_process_id = b.id) b
         where t.id = b.task_form_id) t
  left join (select c.id                   as detail_data_id,
                    d.id                   as data_id,
                    c.isstate,
                    c.value,
                    d.basicid,
                    c.form_process_risk_id as itemid
               from t_Form_Process_risk_data c, t_form_process_data d
              where c.form_process_data_id = d.id) p
    on p.itemid = t.id
   and p.basicid = t.taskid
/

