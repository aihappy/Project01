create view V_SB_ITEM as
  select rownum id, a."SBID", a."SBNAME", a."ITEMID", a."ITEMNAME"
  from (select distinct sbid, sbname, itemid, itemname
          from v_data_analis
        /* where isanalysised = 0*/) a
/

