create view V_FORM_DETAIL as
  select t.id, t.parent_id, t.show_name, t.detail_Id,t.office_id,
(case
    when p.detail_id is null then
       0
    else
       1
    end) as selected
from (
    select 'f'||t.id as id, '0' as parent_id, t.name as show_name, t.id as detail_id,t.office_id from t_task_form t
        where t.task_status=(select max(t.value) from sys_dict t where t.type='process_status_form')
        and t.id in(select r.task_form_id from t_parent_children r,t_form_header q where r.id=q.formid and q.data_type=1)
    union all
        select 'p'||t.id as id, 'f'||t.task_form_id as parent_id, t.name as show_name, t.id as detail_id, a.office_id
        from t_parent_children t left join t_task_form a on t.task_form_id=a.id
        where t.id in(select q.formid from t_form_header q where q.data_type=1)
    union all
        select 'd'||t.id as id, 'p'||t.formid as parent_id, t.asset_name as show_name, t.id as detail_id, b.office_id
        from t_form_detail t, t_parent_children a, t_task_form b
        where t.formid in(select q.formid from t_form_header q where q.data_type=1)
        and t.formid=a.id and a.task_form_id=b.id
) t
left join (select distinct f.detail_id from t_analyze_detail_header f where f.del_flag='0') p on p.detail_id=t.detail_id
order by t.id
/

