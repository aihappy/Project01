create view V_AI_DLT as
  select a1.q1, a1.s1, a2.q2, a2.s2, a3.q3, a3.s3, a4.q4, a4.s4, a5.q5, a5.s5,h1.h1,h1.hs1,h2.h2,h2.hs2
  from (select q1, s1, rownum rn
          from (select q1, s1
                  from (select t.q1, count(*) as s1
                          from AI_DLT t
                         group by t.q1)
                 order by s1 desc)) a1
  full join (select q2, s2, rownum rn
               from (select q2, s2
                       from (select t.q2, count(*) as s2
                               from AI_DLT t
                              group by t.q2)
                      order by s2 desc)) a2
    on a1.rn = a2.rn
  full join (select q3, s3, rownum rn
               from (select q3, s3
                       from (select t.q3, count(*) as s3
                               from AI_DLT t
                              group by t.q3)
                      order by s3 desc)) a3
    on a1.rn = a3.rn
     full join (select q4, s4, rownum rn
               from (select q4, s4
                       from (select t.q4, count(*) as s4
                               from AI_DLT t
                              group by t.q4)
                      order by s4 desc)) a4
    on a1.rn = a4.rn
     full join (select q5, s5, rownum rn
               from (select q5, s5
                       from (select t.q5, count(*) as s5
                               from AI_DLT t
                              group by t.q5)
                      order by s5 desc)) a5
    on a1.rn = a5.rn
    full join (select h1, hs1, rownum rn
               from (select h1, hs1
                       from (select t.h1, count(*) as hs1
                               from AI_DLT t
                              group by t.h1)
                      order by hs1 desc)) h1
    on a1.rn = h1.rn
     full join (select h2, hs2, rownum rn
               from (select h2, hs2
                       from (select t.h2, count(*) as hs2
                               from AI_DLT t
                              group by t.h2)
                      order by hs2 desc)) h2
    on a1.rn = h2.rn
/

