create PROCEDURE     PROC_PARAM_TO_BASIC
/*
  加工内容:从一体化设备表技术参数表
  来源表：DM_DEVICE 一体化设备表
          T_SYNC 同步时间表
  目的表：T_ASSET_BASIC 设备基本信息和技术参数表
          T_SYNC 同步时间表
  创建时间: 2017-03-23
  修改时间：2017-03-23
  */
 AS
  D_STMT      VARCHAR(1000);
  D_PROC_TYPE VARCHAR(1000) DEFAULT '技术参数表加工';
  D_PROC_NAME VARCHAR(1000) DEFAULT '技术参数';
  D_TABLE_NAME VARCHAR(1000) DEFAULT 'DM_PARAM';
  D_SYNC_DATE     DATE DEFAULT TO_DATE('19900101','YYYYMMDD');
  D_MAX_DATE      DATE DEFAULT TO_DATE('19900101','YYYYMMDD');
  D_SYNC_COUNT  NUMBER DEFAULT 0;
  D_NAME VARCHAR(1000);
  D_SQL VARCHAR(1000);
  D_VALUE VARCHAR(1000);
BEGIN
  --加工日志
  D_STMT := 'CALL PROC_LOG(:1,:2,:3,:4)';
  EXECUTE IMMEDIATE D_STMT
    USING D_PROC_TYPE, D_PROC_NAME, '加工开始', 0;

  --取出上次同步时间作为本次同步最小时间
  SELECT COUNT(*) INTO D_SYNC_COUNT FROM T_SYNC T WHERE T.TABLE_NAME=D_TABLE_NAME;
  IF D_SYNC_COUNT =1 THEN
    SELECT T.SYNC_TIME INTO D_SYNC_DATE FROM T_SYNC T WHERE T.TABLE_NAME=D_TABLE_NAME;
  END IF;
  --取出本次同步的最大时间最为本次同步时间入库
  --SELECT MAX(T.UPDATE_TIME) INTO D_MAX_DATE FROM DM_DEVICE T ;
  --循环取值组合数据
FOR d IN
  ( SELECT * FROM DM_DEVICE T )
LOOP
     select t.table_name into D_NAME from dm_classify t where t.id=d.Classify_Id;
     FOR CT IN
       (select p.column_name,DECODE(p.data_type,2,1,0) as list_type,p.sort_no as sx,d.techparam_name||
       case when d.units is not null then '('||d.units||')' else '' end as asset_list,p.classify_id,'' AS ASSET_VALUE
       from dm_classify_techparam p left join dm_techparam d on d.id=p.techparam_id
       where p.classify_id=D.CLASSIFY_ID)
     LOOP
        D_SQL := 'select '|| CT.COLUMN_NAME||' from ' ||D_NAME||' WHERE ID='||''''||D.ID||'''';
        --D_SQL :='select bureau_code from DM_A_TRANSFORMER WHERE ID='||''''||'0109723808BD'||'''';
        begin
        execute immediate D_SQL into D_VALUE;
        exception
           when others then
             D_VALUE:='';
             INSERT INTO T_ASSET_BASIC(ID, ASSET_ID, ASSET_LIST, ASSET_VALUE,COLUMN_NAME,LIST_TYPE, DEL_FLAG, CREATE_DATE, UPDATE_DATE,SX, TYPE)
             VALUES(SEQ_ASSET_BASIC.NEXTVAL,D.ID,CT.ASSET_LIST,D_VALUE,CT.COLUMN_NAME,CT.LIST_TYPE,'0',SYSDATE,SYSDATE,CT.SX,1);
             COMMIT;
           end;
        --CT.ASSET_VALUE:=D_VALUE;
        INSERT INTO T_ASSET_BASIC(ID, ASSET_ID, ASSET_LIST, ASSET_VALUE,COLUMN_NAME,LIST_TYPE, DEL_FLAG, CREATE_DATE, UPDATE_DATE,SX, TYPE)
        VALUES(SEQ_ASSET_BASIC.NEXTVAL,D.ID,CT.ASSET_LIST,D_VALUE,CT.COLUMN_NAME,CT.LIST_TYPE,'0',SYSDATE,SYSDATE,CT.SX,1);
          COMMIT;
     END LOOP;
END LOOP;




  --加工结束保存时间
   IF D_SYNC_COUNT =0 THEN
     INSERT INTO T_SYNC(TABLE_NAME,SYNC_TIME,UPDATE_TIME)
     VALUES(D_TABLE_NAME,D_MAX_DATE,SYSDATE);
   ELSE
     UPDATE T_SYNC SET SYNC_TIME = D_MAX_DATE,UPDATE_TIME=SYSDATE WHERE TABLE_NAME=D_TABLE_NAME;
   END IF;
    COMMIT;
  --加工日志
  EXECUTE IMMEDIATE D_STMT
    USING D_PROC_TYPE, D_PROC_NAME, '加工结束', 0;
  --提交
  COMMIT;
  --异常处理
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    EXECUTE IMMEDIATE D_STMT
      USING D_PROC_TYPE, D_PROC_NAME, '存储过程调用失败; SQLCODE:' || SQLCODE || '; SQLERRM:' || SQLERRM, 0;
    COMMIT;
    RAISE;
END;
/

