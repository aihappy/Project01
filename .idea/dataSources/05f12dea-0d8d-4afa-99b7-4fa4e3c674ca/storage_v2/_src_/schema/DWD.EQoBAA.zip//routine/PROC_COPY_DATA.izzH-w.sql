create PROCEDURE PROC_COPY_DATA(PLANTASKID IN NUMBER, --T_PLAN_TASK ID
                                           C_BASICID  OUT NUMBER)
/*
  加工内容: 用于数据填报时对数据拷贝
  创建人:艾贵
  创建时间:2014-08-25
  */
 AS
  D_BASICID   NUMBER DEFAULT 0;
  D_PROCESSID NUMBER DEFAULT 0;
  C_TASKID    NUMBER DEFAULT 0;
  D_STARTTIME DATE DEFAULT SYSDATE;
  D_ENDTIME   DATE DEFAULT SYSDATE;
  D_COUNT     NUMBER DEFAULT 0;
BEGIN
  --1，查询出对应的数据库记录
  C_BASICID := 0;
  SELECT COUNT(*) INTO D_COUNT FROM T_PLAN_TASK T WHERE T.ID = PLANTASKID; -- AND T.FINISHED=0
  IF (D_COUNT = 1) THEN
    SELECT T.PREV_TASK_ID,
           T.TASK_ID,
           P.FORM_CLASS_ID AS TASKID,
           T.SCHEDULE_DATE,
           T.SCHEDFINISH
      INTO D_BASICID, C_BASICID, C_TASKID, D_STARTTIME, D_ENDTIME
      FROM T_PLAN_TASK T, T_TASK_FORM P
     WHERE P.ID = T.JOBFORM_ID
       AND T.ID = PLANTASKID; -- AND T.FINISHED=0
    --2.向T_DATA_BASIC表插入一条记录 并获取记录ID
    --SELECT SEQUENCE_DATABASIC.NEXTVAL INTO C_BASICID FROM DUAL;
    IF (C_BASICID > 0) THEN
      SELECT COUNT(*)
        INTO D_COUNT
        FROM T_DATA_BASIC T
       WHERE T.ID = C_BASICID;
      IF (D_COUNT = 0) THEN
        DELETE FROM T_DATA_BASIC T WHERE T.ID = C_BASICID;
        DELETE FROM T_FORM_PREPARE_DATA T WHERE T.BASICID = C_BASICID;
        DELETE FROM T_FORM_PROCESS_CONTENT_DATA P
         WHERE P.FORM_PROCESS_DATA_ID IN
               (SELECT T.ID
                  FROM T_FORM_PROCESS_DATA T
                 WHERE T.BASICID = C_BASICID);
        DELETE FROM T_FORM_PROCESS_RISK_DATA P
         WHERE P.FORM_PROCESS_DATA_ID IN
               (SELECT T.ID
                  FROM T_FORM_PROCESS_DATA T
                 WHERE T.BASICID = C_BASICID);
        DELETE FROM T_FORM_PROCESS_DATA T WHERE T.BASICID = C_BASICID;
        DELETE FROM T_FORM_EVALUATE_DATA T WHERE T.BASICID = C_BASICID;
        DELETE FROM T_DATA T WHERE T.BASICID = C_BASICID;
        DELETE FROM T_OPEN_CLOSE_PATROL T WHERE T.BASICID = C_BASICID;
        DELETE FROM T_FORM_REMARK_DATA T WHERE T.BASICID = C_BASICID;
        DELETE FROM T_FORM_SUPPLE_DATA T WHERE T.BASICID = C_BASICID;
        COMMIT;
        SELECT COUNT(*)
          INTO D_COUNT
          FROM T_DATA_BASIC T
         WHERE T.ID = D_BASICID;
        IF (D_COUNT = 1) THEN
          INSERT INTO T_DATA_BASIC
            (ID,
             ZYBZID,
             STARTTIME,
             ENDTIME,
             TASKID,
             FZRID,
             ZYRID,
             TQ,
             CHECKDATE,
             SHRID)
            SELECT C_BASICID,
                   T.ZYBZID,
                   D_STARTTIME,
                   D_ENDTIME,
                   C_TASKID,
                   NULL,
                   T.ZYRID,
                   T.TQ,
                   NULL,
                   NULL
              FROM T_DATA_BASIC T
             WHERE T.ID = D_BASICID;
          --2，拷贝数据库记录
          INSERT INTO T_FORM_PREPARE_DATA
            (ID, BASICID, ITEMID, ISSTATE, VALUE)
            SELECT SEQUENCE_PREPAREDATA.NEXTVAL,
                   C_BASICID,
                   T.ITEMID,
                   T.ISSTATE,
                   T.VALUE
              FROM T_FORM_PREPARE_DATA T
             WHERE T.BASICID = D_BASICID;
        
          SELECT SEQUENCE_PROCESSDATA.NEXTVAL INTO D_PROCESSID FROM DUAL;
          INSERT INTO T_FORM_PROCESS_DATA
            (ID, BASICID)
          VALUES
            (D_PROCESSID, C_BASICID);
        
          INSERT INTO T_FORM_PROCESS_CONTENT_DATA
            (ID,
             FORM_PROCESS_DATA_ID,
             ISSTATE,
             VALUE,
             FORM_PROCESS_CONTENT_ID)
            SELECT SEQUENCE_PROCESSDATA.NEXTVAL,
                   D_PROCESSID,
                   P.ISSTATE,
                   P.VALUE,
                   P.FORM_PROCESS_CONTENT_ID
              FROM T_FORM_PROCESS_DATA T, T_FORM_PROCESS_CONTENT_DATA P
             WHERE P.FORM_PROCESS_DATA_ID = T.ID
               AND T.BASICID = D_BASICID;
        
          INSERT INTO T_FORM_PROCESS_RISK_DATA
            (ID,
             FORM_PROCESS_DATA_ID,
             ISSTATE,
             VALUE,
             FORM_PROCESS_RISK_ID)
            SELECT SEQUENCE_PROCESSDATA.NEXTVAL,
                   D_PROCESSID,
                   P.ISSTATE,
                   P.VALUE,
                   P.FORM_PROCESS_RISK_ID
              FROM T_FORM_PROCESS_DATA T, T_FORM_PROCESS_RISK_DATA P
             WHERE P.FORM_PROCESS_DATA_ID = T.ID
               AND T.BASICID = D_BASICID;
        
          INSERT INTO T_FORM_EVALUATE_DATA
            (ID, BASICID, ITEMID, ISSTATE, VALUE, QLXC, ZYPJ, XZFX)
            SELECT SEQUENCE_EVALUEATEDATA.NEXTVAL,
                   C_BASICID,
                   T.ITEMID,
                   T.ISSTATE,
                   T.VALUE,
                   T.QLXC,
                   T.ZYPJ,
                   T.XZFX
              FROM T_FORM_EVALUATE_DATA T
             WHERE T.BASICID = D_BASICID;
        
          INSERT INTO T_DATA
            (ID, BASICID, PARENTID, SBID, ITEMID, VALUE, REMARK, STATUS)
            SELECT SEQUENCE_DATA.NEXTVAL,
                   C_BASICID,
                   T.PARENTID,
                   T.SBID,
                   T.ITEMID,
                   T.VALUE,
                   T.REMARK,
                   T.STATUS
              FROM T_DATA T
             WHERE T.BASICID = D_BASICID;
        
          INSERT INTO T_OPEN_CLOSE_PATROL
            (ID,
             BASICID,
             PARENTID,
             SBID,
             HEADER_ID,
             ASSET_NAME,
             VALUE,
             DEL_FLAG,
             CREATE_DATE,
             REMARKS)
            SELECT SEQ_OPENCLOSEPATROL.NEXTVAL,
                   C_BASICID,
                   T.PARENTID,
                   T.SBID,
                   T.HEADER_ID,
                   T.ASSET_NAME,
                   T.VALUE,
                   T.DEL_FLAG,
                   T.CREATE_DATE,
                   T.REMARKS
              FROM T_OPEN_CLOSE_PATROL T
             WHERE T.BASICID = D_BASICID;
        
          INSERT INTO T_FORM_REMARK_DATA
            (ID, BASICID, ITEMID, ISSTATE, VALUE, FORMID)
            SELECT SEQUENCE_FORM_REMARK_DATA.NEXTVAL,
                   C_BASICID,
                   T.ITEMID,
                   T.ISSTATE,
                   T.VALUE,
                   T.FORMID
              FROM T_FORM_REMARK_DATA T
             WHERE T.BASICID = D_BASICID;
        
          INSERT INTO T_FORM_SUPPLE_DATA
            (ID, BASICID, ITEMID, ISSTATE, VALUE, FORMID)
            SELECT SEQUENCE_FORM_SUPPLE_DATA.NEXTVAL,
                   C_BASICID,
                   T.ITEMID,
                   T.ISSTATE,
                   T.VALUE,
                   T.FORMID
              FROM T_FORM_SUPPLE_DATA T
             WHERE T.BASICID = D_BASICID;
        
        ELSE
          INSERT INTO T_DATA_BASIC
            (ID,
             ZYBZID,
             STARTTIME,
             ENDTIME,
             TASKID,
             FZRID,
             ZYRID,
             TQ,
             CHECKDATE,
             SHRID)
          VALUES
            (C_BASICID,
             NULL,
             D_STARTTIME,
             D_ENDTIME,
             C_TASKID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL);
        END IF;
      END IF;
    END IF;
  
    UPDATE T_PLAN_TASK T
       SET T.FINISHED = 1, T.ACTFINISH = SYSDATE
     WHERE T.ID = PLANTASKID;
    COMMIT;
  END IF;
  --异常处理
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    C_BASICID := 0;
    RAISE;
END PROC_COPY_DATA;
/

