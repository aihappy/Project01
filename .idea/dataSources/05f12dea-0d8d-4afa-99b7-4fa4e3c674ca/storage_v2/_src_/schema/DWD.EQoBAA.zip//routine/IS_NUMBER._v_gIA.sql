create FUNCTION Is_Number (
   str_    VARCHAR2 ) RETURN VARCHAR2
IS
   num_    NUMBER;
BEGIN
  num_ := to_number(str_);
  RETURN 'Y';
EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N';
END Is_Number;
/

