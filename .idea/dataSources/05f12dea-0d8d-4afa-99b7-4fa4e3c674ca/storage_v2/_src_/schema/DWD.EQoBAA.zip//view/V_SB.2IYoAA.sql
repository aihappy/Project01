create view V_SB as
  select t.id,
       t.PARENT_ID,
       t.show_name,
       t.sb_id,
       t.sb_name,
       t.dwd_id,
       t.dwd_name,
       (case
         when p.sb_id is null then
          0
         else
          1
       end) as selected
  from (select 's' || b.assetnum as id,
               'f' || c.classstructureid as PARENT_ID,
               (case
                 when b.simplename is null then
                  b.description
                 else
                  b.simplename
               end) as show_name,
               b.assetnum as sb_id,
               (case
                 when b.simplename is null then
                  b.description
                 else
                  b.simplename
               end) as sb_name,
               c.classstructureid as dwd_id,
               c.description as dwd_name
          from t_form_detail a, t_sb b, dwdclassstructure c
         where c.classstructureid = b.classify
           and b.assetnum = a.asset_id
           and a.asset_id is not null
           and c.del_flag = 0
           and a.del_flag = 0
           and b.del_flag = 0
           group by b.assetnum,b.simplename, b.description,c.classstructureid,c.description) t
  left join (select distinct f.sb_id from analyze_sb_item f where f.del_flag='0') p
    on p.sb_id = t.sb_Id
/

